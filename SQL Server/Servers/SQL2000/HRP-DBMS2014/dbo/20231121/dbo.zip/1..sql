SELECT nb.k6040 ,zcpt.K6040,
case when left(k0101,1)in ('H','G','T','S') then rtrim(replace(replace(replace(replace(replace(replace(nb.k0101,'H','G'),'T','S'),'D003',''),'D002',''),'D001',''),'000000',''))+rtrim(nb.a0103)+'L'+rtrim(nb.k6001)
else left(nb.k0101,4)+rtrim(nb.a0103)+'L'+rtrim(nb.k6001) end

from ZCPT_K060 ZCPT 
right join K060 nb on 
case when left(k0101,1)in ('H','G','T','S') then rtrim(replace(replace(replace(replace(replace(replace(nb.k0101,'H','G'),'T','S'),'D003',''),'D002',''),'D001',''),'000000',''))+rtrim(nb.a0103)+'L'+rtrim(nb.k6001)
else left(nb.k0101,4)+rtrim(nb.a0103)+'L'+rtrim(nb.k6001) end=rtrim(zcpt.k6001)

case when left(k0101,1)in ('H','G','T','S') then rtrim(replace(replace(replace(replace(replace(replace(nb.k0101,'H','G'),'T','S'),'D003',''),'D002',''),'D001',''),'000000',''))+rtrim(nb.a0103)+'L'+rtrim(nb.k6001)
else left(k0101,4)+rtrim(nb.a0103)+'L'+rtrim(nb.k6001) end


update  ZCPT set zcpt.K6040 =nb.k6040
from ZCPT_K060  ZCPT
left join K060 nb on rtrim(replace(replace(replace(replace(nb.k0101,'D003',''),'D002',''),'D001',''),'000000',''))+rtrim(nb.a0103)+'L'+rtrim(nb.k6001) =rtrim(zcpt.k6001)

SELECT k6001,K6040 from ZCPT_K060
SELECT rtrim(replace(replace(replace(replace(nb.k0101,'D003',''),'D002',''),'D001',''),'000000',''))+rtrim(nb.a0103)+'L'+rtrim(nb.k6001),K6040 from K060