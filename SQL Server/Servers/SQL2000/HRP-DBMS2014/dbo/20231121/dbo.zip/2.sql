SELECT 
		'K060'+'&K0101 ='''+RTRIM(CAST(zcpt.K0101 AS VARCHAR))+''' AND A0102='''+RTRIM(CAST(zcpt.A0102 AS VARCHAR))+''' AND K6001 ='''+RTRIM(CAST(zcpt.K6001 AS VARCHAR))+''''  AS 编辑,
zcpt.a0102,
zcpt.ha0102,
replace(replace(replace(replace(zcpt.k0101,'D003',''),'D002',''),'D001',''),'000000','') k0101,
zcpt.k0101 [资产平台路线编码],
zcpt.k0112,
zcpt.k0112 [资产平台路线名称],
rtrim(replace(replace(replace(replace(zcpt.k0101,'D003',''),'D002',''),'D001',''),'000000',''))+rtrim(zcpt.a0103)+'L'+rtrim(zcpt.k6001) k6001,
zcpt.k6001 [资产平台桥梁编码],
zcpt.k6002,
zcpt.k6002 [资产平台桥梁名称],
zcpt.k6003,
zcpt.k6003 [资产平台桥梁位置桩号]
from 
k060 nb
join ZCPT_K060 zcpt on zcpt.k6040=zcpt.k6040 
where  (replace(replace(replace(replace(zcpt.k0101,'D003',''),'D002',''),'D001',''),'000000','')<>zcpt.K0101
or zcpt.k0112<>zcpt.k0112
or rtrim(replace(replace(replace(replace(zcpt.k0101,'D003',''),'D002',''),'D001',''),'000000',''))+rtrim(zcpt.a0103)+'L'+rtrim(zcpt.k6001)<>zcpt.k6001
or zcpt.k6002<>zcpt.k6002 or zcpt.k6003<>zcpt.k6003
)
AND zcpt.A0102 LIKE '#A0102#%' AND zcpt.A0102 LIKE '#GLDW#%'

